document.querySelector('#form-inscription').addEventListener('submit', function(e) {
    e.preventDefault();

    let isValid = true;

    const errors = document.querySelectorAll('.error');
    for(let error of errors) {
        error.textContent = "";
    }

    const nom = document.querySelector('#nom');
    if(nom.value.length < 3) {
        const error = document.querySelector('#nom-error');
        error.textContent = "Le nom doit faire plus de 3 caractères";
        isValid = false;
    }

    const prenom = document.querySelector('#prenom');
    if(prenom.value.length < 2) {
        const error = document.querySelector('#prenom-error');
        error.textContent = "Le prenom doit faire plus de 2 caractères";
        isValid = false;
    }

    const email = document.querySelector('#email');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(!emailRegex.test(email.value)) {
        const error = document.querySelector('#email-error');
        error.textContent = "L'email est invalide";
        isValid = false;
    }
    
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    const password = document.querySelector('#password');
    if(!passwordRegex.test(password.value)) {
        const error = document.querySelector('#password-error');
        error.textContent = "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre.";
        isValid = false;
    }

    const age = document.querySelector('#age');
    if(age.value < 18 || age.value > 99 || isNaN(age.value)) {
        const error = document.querySelector('#age-error');
        error.textContent = "L'âge doit être un nombre entre 18 et 99";
        isValid = false;
    }

    if(isValid) {
        alert('Le formulaire est valide');
    }
})