document.getElementById("form-inscription").addEventListener("submit", function (event) {
    event.preventDefault(); // Empêche l'envoi du formulaire

    // Récupération des champs
    const nom = document.getElementById("nom");
    const prenom = document.getElementById("prenom");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const age = document.getElementById("age");

    // Récupération des valeurs
    const nomValue = nom.value.trim();
    const prenomValue = prenom.value.trim();
    const emailValue = email.value.trim();
    const passwordValue = password.value;
    const ageValue = age.value;

    // Récupération des éléments d'erreur
    const nomError = document.getElementById("nom-error");
    const prenomError = document.getElementById("prenom-error");
    const emailError = document.getElementById("email-error");
    const passwordError = document.getElementById("password-error");
    const ageError = document.getElementById("age-error");

    // Réinitialisation des messages et styles d'erreur
    [nom, prenom, email, password, age].forEach(input => input.classList.remove("error-field"));

    // [nom, prenom, email, password, age].forEach(function(input) {
    //     input.classList.remove("error-field");
    // });

    [nomError, prenomError, emailError, passwordError, ageError].forEach(error => error.textContent = "");

    let isValid = true;

    // Validation du nom
    if (nomValue.length < 3) {
        nomError.textContent = "Le nom doit contenir au moins 3 caractères.";
        nom.classList.add("error-field");
        isValid = false;
    }

    // Validation du prénom
    if (prenomValue.length < 2) {
        prenomError.textContent = "Le prénom doit contenir au moins 2 caractères.";
        prenom.classList.add("error-field");
        isValid = false;
    }

    // Validation de l'email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailValue)) {
        emailError.textContent = "Veuillez entrer une adresse e-mail valide.";
        email.classList.add("error-field");
        isValid = false;
    }

    // Validation du mot de passe
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordRegex.test(passwordValue)) {
        passwordError.textContent = "Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule et un chiffre.";
        password.classList.add("error-field");
        isValid = false;
    }

    // Validation de l'âge
    const ageNumber = parseInt(ageValue);
    if (isNaN(ageNumber) || ageNumber < 18 || ageNumber > 99) {
        ageError.textContent = "L'âge doit être un nombre entre 18 et 99.";
        age.classList.add("error-field");
        isValid = false;
    }

    // Si tout est valide, afficher le message
    if (isValid) {  
        alert("Le formulaire est valide :)")
    }
});
